/*! 
 * Nova Creator Bootstrap Datagrid v1.0.0 - 07/18/2020
 * Copyright (c) 2015-2020 Nova Creator Software (https://github.com/NovaCreatorSoftware/bootstrap-data-grid)
 * Licensed under MIT http://www.opensource.org/licenses/MIT
 */
;(function ($, window, undefined)
{
    /*jshint validthis: true */
    "use strict";

/*$.extend($.fn.tablear.Constructor.defaults.css, {
    icon: "icon fa",
    iconColumns: "fa-th-list",
    iconUp: "fa-sort-asc",
    iconDown: "fa-sort-desc",
    iconRefresh: "fa-refresh",
    iconSearch: "fa-search"
});*/
})(jQuery, window);