/*! 
 * Nova Creator Bootstrap Datagrid v1.0.0 - 07/13/2016
 * Copyright (c) 2015-2016 Nova Creator Software (https://github.com/NovaCreatorSoftware/bootstrap-data-grid)
 * Licensed under MIT http://www.opensource.org/licenses/MIT
 */
;(function ($, window, undefined)
{
    /*jshint validthis: true */
    "use strict";

/*$.extend($.fn.tablear.Constructor.defaults.css, {
    icon: "icon fa",
    iconColumns: "fa-th-list",
    iconUp: "fa-sort-asc",
    iconDown: "fa-sort-desc",
    iconRefresh: "fa-refresh",
    iconSearch: "fa-search"
});*/
})(jQuery, window);